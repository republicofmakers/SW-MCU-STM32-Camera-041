#ifndef OV2640_H
#define OV2640_H

#include "main.h"
#include "camera.h"


int ov2640_init(framesize_t framesize);

#endif
